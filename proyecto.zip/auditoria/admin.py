from django.contrib import admin
from .models import Auditoria

admin.site.register(Auditoria)