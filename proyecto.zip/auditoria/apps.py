from django.apps import AppConfig


class AuditoriaConfig(AppConfig):
    name = 'auditoria'
